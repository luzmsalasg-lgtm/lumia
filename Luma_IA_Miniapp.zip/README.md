# Luma IA — Miniapp comercial

Nivel 1 BLAST: sitio estático sin cuentas ni backend. Estilo azul noche #101828, dorado #D4AF37 y marfil #F8F6F0.

## Contenido
- index.html: interfaz y lógica
- manifest.webmanifest: configuración instalable
- sw.js: caché de recursos locales
- assets/: logo, fotografía e iconos aportados

## Probar
Abrir index.html permite revisar contenido y enlaces; para PWA usar un servidor local (por ejemplo `python -m http.server 8000`) y visitar http://localhost:8000. La instalación y QR definitivo requieren publicar por HTTPS.

## Publicar en Netlify
1. Entrar a https://app.netlify.com/ y crear un sitio mediante despliegue manual.
2. Arrastrar la carpeta `luma-ia-miniapp` que contiene index.html (o el ZIP si la interfaz lo admite).
3. Hacer público el sitio si aparece como privado y abrir el enlace HTTPS.
4. Comprobar botones, redes, QR e instalación en Android y iPhone.
5. Si cambias imágenes o textos, volver a publicar. El servicio worker puede mantener caché hasta que actualices la versión `luma-ia-v1`.

## Límites y pendientes
- No hay casos de éxito ni testimonios inventados; portafolio pendiente de aportar.
- Horario 9–18 h sin días definidos. Los precios se muestran como solicitud de cotización.
- QR se obtiene de un servicio público externo al abrir la app en HTTPS; necesita conexión para mostrarse y comparte la URL pública con el proveedor del QR.
- WhatsApp, Instagram y Facebook dependen de servicios externos. Los enlaces deben comprobarse en dispositivos reales.
- No hay pagos, analíticas, formularios ni base de datos.
- Netlify Free tiene límite de 300 créditos mensuales según su página oficial (noviembre de 2026). Si se agotan, el sitio puede pausarse hasta el siguiente ciclo.
- PWA puede ser instalable cuando el navegador lo permita, no está garantizada en todos los dispositivos.
